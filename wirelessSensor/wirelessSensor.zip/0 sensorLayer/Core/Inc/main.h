/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define KEY1_Pin GPIO_PIN_13
#define KEY1_GPIO_Port GPIOC
#define KEY2_Pin GPIO_PIN_14
#define KEY2_GPIO_Port GPIOC
#define KEY3_Pin GPIO_PIN_15
#define KEY3_GPIO_Port GPIOC
#define SMOKE_IN_Pin GPIO_PIN_4
#define SMOKE_IN_GPIO_Port GPIOA
#define ADJRES_IN_Pin GPIO_PIN_5
#define ADJRES_IN_GPIO_Port GPIOA
#define PHOTORES_IN_Pin GPIO_PIN_6
#define PHOTORES_IN_GPIO_Port GPIOA
#define PIR_IN_Pin GPIO_PIN_7
#define PIR_IN_GPIO_Port GPIOA
#define LED_RED_Pin GPIO_PIN_0
#define LED_RED_GPIO_Port GPIOB
#define LED_YEL_Pin GPIO_PIN_1
#define LED_YEL_GPIO_Port GPIOB
#define LED_GRE_Pin GPIO_PIN_2
#define LED_GRE_GPIO_Port GPIOB
#define PWM_LED_Pin GPIO_PIN_3
#define PWM_LED_GPIO_Port GPIOB
#define RELAY_Pin GPIO_PIN_4
#define RELAY_GPIO_Port GPIOB
#define SMOKE_EN_Pin GPIO_PIN_5
#define SMOKE_EN_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
